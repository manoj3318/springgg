package com.gavs.springboot.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gavs.springboot.task.model.Task;
import com.gavs.springboot.task.repository.TaskRepository;


@Service
public class TaskService {
	@Autowired
	private TaskRepository repo;
	public List<Task> getAllTasks()
	{
		return repo.findAll();
	}
}
