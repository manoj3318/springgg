package com.gavs.springboot.task.controller;

import java.sql.SQLException;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gavs.springboot.task.model.Task;
import com.gavs.springboot.task.repository.TaskRepository;


@RestController
public class TaskController {
@Autowired
	private TaskRepository repo;
@RequestMapping(value="/findTask",method=RequestMethod.GET)
public Task findTask(int task_id)
{
	Optional<Task> found=repo.findById(task_id);
	Task t1= found.get();
	System.out.println(t1.getTask_id());
	return t1;
}
@RequestMapping(value="/addTask",method=RequestMethod.POST)
public int addTask(@RequestBody Task t1) throws SQLException
{
	repo.save(t1);
	return 0;
}
@RequestMapping(value="/modifyTask",method=RequestMethod.PUT)
public int ModifyTask(@RequestBody Task t1)
{
	repo.save(t1);
	return 0;
}
@RequestMapping(value="/deleteTask",method=RequestMethod.DELETE)
public int DeleteTask(@RequestBody Task t1)
{
	repo.deleteById(t1.getTask_id());
	return 0;
}
}