package com.gavs.springboot.task.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;
@Entity
@Table(name="task1")
public class Task {
	@Column(name="no_of_persons")
	private int no_of_persons;
	@Id

	@Column(name="task_id")
	
	private int task_id;
	@Column(name="task_name")
	private String task_name;
	@Column(name="start_time")
	private Date start_time;

	@Column(name="end_time")
	private Date end_time;
	@Column(name="assigned_by")
	private String assigned_by;

	@Column(name="assigned_to")
	private String assigned_to;

	@Column(name="priority_level")
	private String priority_level;

	@Column(name="status")
	private String status;
	
	public int getNo_of_persons() {
		return no_of_persons;
	}

	public void setNo_of_persons(int no_of_persons) {
		this.no_of_persons = no_of_persons;
	}

	public int getTask_id() {
		return task_id;
	}

	public void setTask_id(int task_id) {
		this.task_id = task_id;
	}

	public String getTask_name() {
		return task_name;
	}

	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}

	public Date getStart_time() {
		return start_time;
	}

	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}

	public Date getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}

	public String getAssigned_by() {
		return assigned_by;
	}

	public void setAssigned_by(String assigned_by) {
		this.assigned_by = assigned_by;
	}

	public String getAssigned_to() {
		return assigned_to;
	}

	public void setAssigned_to(String assigned_to) {
		this.assigned_to = assigned_to;
	}

	public String getPriority_level() {
		return priority_level;
	}

	public void setPriority_level(String priority_level) {
		this.priority_level = priority_level;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static void main(String[] args) {
	
}
}